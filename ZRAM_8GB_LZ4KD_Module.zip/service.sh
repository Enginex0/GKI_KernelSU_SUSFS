#!/system/bin/sh
# ZRAM 8GB LZ4KD Configuration
# Author: Enginex0

MODDIR=${0%/*}
LOG="$MODDIR/zram.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG"
}

# Configuration
ZRAM_SIZE=8589934592  # 8GB in bytes
ZRAM_ALGO=lz4kd
MAX_STREAMS=8

log "========================================="
log "=== ZRAM Configuration Service Start ==="
log "========================================="

# Wait for system to stabilize
log "Waiting for system initialization..."
sleep 15

# Stop existing ZRAM
log "Stopping existing ZRAM swap..."
swapoff /dev/block/zram0 2>/dev/null
sleep 2

# Reset ZRAM
log "Resetting ZRAM device..."
echo 1 > /sys/block/zram0/reset 2>/dev/null
sleep 1

# Set compression streams
log "Setting max_comp_streams: $MAX_STREAMS"
echo "$MAX_STREAMS" > /sys/block/zram0/max_comp_streams 2>/dev/null

# Set compression algorithm
log "Setting compression algorithm: $ZRAM_ALGO"
echo "$ZRAM_ALGO" > /sys/block/zram0/comp_algorithm 2>/dev/null

# Set disk size
log "Setting disksize: $ZRAM_SIZE bytes (8GB)"
echo "$ZRAM_SIZE" > /sys/block/zram0/disksize 2>/dev/null

# Initialize swap
log "Initializing swap partition..."
mkswap /dev/block/zram0 > /dev/null 2>&1

log "Enabling swap..."
swapon /dev/block/zram0 > /dev/null 2>&1

# Verify configuration
ACTUAL_SIZE=$(cat /sys/block/zram0/disksize 2>/dev/null)
ACTUAL_ALGO=$(cat /sys/block/zram0/comp_algorithm 2>/dev/null | grep -o '\[.*\]' | tr -d '[]')
[ -z "$ACTUAL_ALGO" ] && ACTUAL_ALGO=$(cat /sys/block/zram0/comp_algorithm 2>/dev/null)

log "----------------------------------------"
log "ZRAM Configuration Result:"
log "  Size: $ACTUAL_SIZE bytes"
log "  Algorithm: $ACTUAL_ALGO"
log "----------------------------------------"

# Log memory status
MEM_INFO=$(free -h 2>/dev/null | grep -E "Mem:|Swap:")
log "Memory Status:"
log "$MEM_INFO"

log "=== ZRAM Configuration Complete ==="
