#!/system/bin/sh
# ZRAM 8GB Module Installation Script

ui_print "========================================="
ui_print "   ZRAM 8GB LZ4KD Configuration Module"
ui_print "   Author: Enginex0"
ui_print "========================================="
ui_print ""
ui_print "Configuration:"
ui_print "  - ZRAM Size: 8GB"
ui_print "  - Algorithm: LZ4KD"
ui_print "  - Streams: 8"
ui_print ""
ui_print "The module will configure ZRAM at boot."
ui_print ""

# Set permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
